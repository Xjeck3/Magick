<?php
namespace ImageApp;
class ImageTransform {
    public function apply(\Imagick $image) {

    }
}
